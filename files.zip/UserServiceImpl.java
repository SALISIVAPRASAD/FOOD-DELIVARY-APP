package com.example.loginapp.service;

import com.example.loginapp.model.RegistrationDto;
import com.example.loginapp.model.User;
import com.example.loginapp.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Constructor injection (recommended over @Autowired on field)
    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public User register(RegistrationDto dto) {
        // Hash password before saving — NEVER store plain text passwords
        String hashedPassword = passwordEncoder.encode(dto.getPassword());

        User user = new User(
            dto.getUsername(),
            dto.getEmail(),
            hashedPassword
        );

        return userRepository.save(user); // JPA runs: INSERT INTO users ...
    }

    @Override
    public boolean usernameExists(String username) {
        return userRepository.existsByUsername(username);
    }

    @Override
    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }
}
