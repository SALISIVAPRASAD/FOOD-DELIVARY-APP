package com.example.loginapp.service;

import com.example.loginapp.model.RegistrationDto;
import com.example.loginapp.model.User;

public interface UserService {
    User register(RegistrationDto dto);
    boolean usernameExists(String username);
    boolean emailExists(String email);
}
