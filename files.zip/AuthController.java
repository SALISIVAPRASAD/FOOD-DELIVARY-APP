package com.example.loginapp.controller;

import com.example.loginapp.model.RegistrationDto;
import com.example.loginapp.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // ── Home ──────────────────────────────────────────────────────────────────

    @GetMapping("/")
    public String home() {
        return "redirect:/dashboard";
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    @GetMapping("/login")
    public String showLoginPage(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            Model model) {

        if (error != null) {
            model.addAttribute("errorMessage", "Invalid username or password.");
        }
        if (logout != null) {
            model.addAttribute("logoutMessage", "You have been logged out successfully.");
        }
        return "login"; // → templates/login.html
    }

    // ── Register ──────────────────────────────────────────────────────────────

    @GetMapping("/register")
    public String showRegisterPage(Model model) {
        model.addAttribute("registrationDto", new RegistrationDto());
        return "register"; // → templates/register.html
    }

    @PostMapping("/register")
    public String processRegistration(
            @Valid @ModelAttribute("registrationDto") RegistrationDto dto,
            BindingResult bindingResult,
            Model model) {

        // Check validation annotations (@NotBlank, @Email, etc.)
        if (bindingResult.hasErrors()) {
            return "register";
        }

        // Check passwords match
        if (!dto.passwordsMatch()) {
            model.addAttribute("passwordError", "Passwords do not match.");
            return "register";
        }

        // Check username not taken
        if (userService.usernameExists(dto.getUsername())) {
            model.addAttribute("usernameError", "Username is already taken.");
            return "register";
        }

        // Check email not taken
        if (userService.emailExists(dto.getEmail())) {
            model.addAttribute("emailError", "An account with this email already exists.");
            return "register";
        }

        // All good — save the user
        userService.register(dto);
        return "redirect:/login?registered=true";
    }

    // ── Dashboard (protected) ─────────────────────────────────────────────────

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard"; // → templates/dashboard.html
    }
}
